# barleyDEG
barleyDEG
